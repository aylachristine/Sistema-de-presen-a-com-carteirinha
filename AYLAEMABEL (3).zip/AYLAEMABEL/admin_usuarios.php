<?php
require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/functions.php';

requireAdmin();

$conn = getDB();
$mensagem = '';
$tipo_mensagem = '';
$acao = $_GET['acao'] ?? 'listar';
$id = $_GET['id'] ?? null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = trim($_POST['nome'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $senha = $_POST['senha'] ?? '';
    $numero_id = trim($_POST['numero_id'] ?? '');
    $turma = trim($_POST['turma'] ?? 'Nao listado');
    $status = $_POST['status'] ?? 'ativo';
    
    if ($acao === 'criar') {
        if (empty($nome) || empty($email) || empty($senha) || empty($numero_id)) {
            $mensagem = 'Por favor, preencha todos os campos obrigatórios.';
            $tipo_mensagem = 'error';
        } elseif (strlen($senha) < 6) {
            $mensagem = 'A senha deve ter no mínimo 6 caracteres.';
            $tipo_mensagem = 'error';
        } else {
            $stmt = $conn->prepare("SELECT id FROM usuarios WHERE email = ?");
            $stmt->execute([$email]);
            if ($stmt->rowCount() > 0) {
                $mensagem = 'Este email já está cadastrado.';
                $tipo_mensagem = 'error';
            } else {
                $stmt = $conn->prepare("SELECT id FROM usuarios WHERE numero_id = ?");
                $stmt->execute([$numero_id]);
                if ($stmt->rowCount() > 0) {
                    $mensagem = 'Este número de ID já está em uso.';
                    $tipo_mensagem = 'error';
                } else {
                    $stmt = $conn->prepare("
                        INSERT INTO usuarios (nome, email, senha, numero_id, turma, status) 
                        VALUES (?, ?, ?, ?, ?, ?)
                    ");
                    if ($stmt->execute([$nome, $email, $senha, $numero_id, $turma, $status])) {
                        $mensagem = 'Usuário criado com sucesso!';
                        $tipo_mensagem = 'success';
                        $acao = 'listar';
                    } else {
                        $mensagem = 'Erro ao criar usuário.';
                        $tipo_mensagem = 'error';
                    }
                }
            }
        }
    } elseif ($acao === 'editar' && $id) {
        if (empty($nome) || empty($email) || empty($numero_id)) {
            $mensagem = 'Por favor, preencha todos os campos obrigatórios.';
            $tipo_mensagem = 'error';
        } else {
            $stmt = $conn->prepare("SELECT id FROM usuarios WHERE email = ? AND id != ?");
            $stmt->execute([$email, $id]);
            if ($stmt->rowCount() > 0) {
                $mensagem = 'Este email já está sendo usado por outro usuário.';
                $tipo_mensagem = 'error';
            } else {
                $stmt = $conn->prepare("SELECT id FROM usuarios WHERE numero_id = ? AND id != ?");
                $stmt->execute([$numero_id, $id]);
                if ($stmt->rowCount() > 0) {
                    $mensagem = 'Este número de ID já está em uso por outro usuário.';
                    $tipo_mensagem = 'error';
                } else {
                    if (!empty($senha)) {
                        if (strlen($senha) < 6) {
                            $mensagem = 'A senha deve ter no mínimo 6 caracteres.';
                            $tipo_mensagem = 'error';
                        } else {
                            $stmt = $conn->prepare("
                                UPDATE usuarios 
                                SET nome = ?, email = ?, senha = ?, numero_id = ?, turma = ?, status = ? 
                                WHERE id = ?
                            ");
                            $result = $stmt->execute([$nome, $email, $senha, $numero_id, $turma, $status, $id]);
                        }
                    } else {
                        $stmt = $conn->prepare("
                            UPDATE usuarios 
                            SET nome = ?, email = ?, numero_id = ?, turma = ?, status = ? 
                            WHERE id = ?
                        ");
                        $result = $stmt->execute([$nome, $email, $numero_id, $turma, $status, $id]);
                    }
                    
                    if (isset($result) && $result) {
                        $mensagem = 'Usuário atualizado com sucesso!';
                        $tipo_mensagem = 'success';
                        $acao = 'listar';
                    } elseif (!isset($result)) {
                    } else {
                        $mensagem = 'Erro ao atualizar usuário.';
                        $tipo_mensagem = 'error';
                    }
                }
            }
        }
    }
}

if ($acao === 'deletar' && $id) {
    if ($id == $_SESSION['usuario_id']) {
        $mensagem = 'Você não pode deletar seu próprio usuário.';
        $tipo_mensagem = 'error';
    } else {
        $stmt = $conn->prepare("DELETE FROM usuarios WHERE id = ?");
        if ($stmt->execute([$id])) {
            $mensagem = 'Usuário deletado com sucesso!';
            $tipo_mensagem = 'success';
        } else {
            $mensagem = 'Erro ao deletar usuário.';
            $tipo_mensagem = 'error';
        }
    }
    $acao = 'listar';
}

$usuarios = [];
if ($acao === 'listar') {
    $stmt = $conn->query("SELECT * FROM usuarios ORDER BY data_cadastro DESC");
    $usuarios = $stmt->fetchAll();
}

$usuario_edicao = null;
if ($acao === 'editar' && $id) {
    $stmt = $conn->prepare("SELECT * FROM usuarios WHERE id = ?");
    $stmt->execute([$id]);
    $usuario_edicao = $stmt->fetch();
    if (!$usuario_edicao) {
        $mensagem = 'Usuário não encontrado.';
        $tipo_mensagem = 'error';
        $acao = 'listar';
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gerenciar Usuários - Admin</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <?php include __DIR__ . '/includes/navbar.php'; ?>
    
    <div class="container">
        <h1>Gerenciar Usuários</h1>
        
        <div style="margin-bottom: 20px;">
            <a href="admin.php" class="btn btn-secondary">← Voltar para Admin</a>
            <a href="?acao=criar" class="btn btn-primary">+ Novo Usuário</a>
        </div>
        
        <?php if ($mensagem): ?>
            <div class="alert alert-<?php echo $tipo_mensagem; ?>">
                <?php echo e($mensagem); ?>
            </div>
        <?php endif; ?>
        
        <?php if ($acao === 'criar' || ($acao === 'editar' && $usuario_edicao)): ?>
            <div class="card">
                <div class="card-body">
                    <h2><?php echo $acao === 'criar' ? 'Criar Novo Usuário' : 'Editar Usuário'; ?></h2>
                    <form method="POST" action="?acao=<?php echo $acao; ?><?php echo $id ? '&id=' . $id : ''; ?>">
                        <div class="form-group">
                            <label for="nome">Nome Completo *</label>
                            <input type="text" id="nome" name="nome" required 
                                   value="<?php echo e($usuario_edicao['nome'] ?? ''); ?>">
                        </div>
                        
                        <div class="form-group">
                            <label for="email">E-mail *</label>
                            <input type="email" id="email" name="email" required 
                                   value="<?php echo e($usuario_edicao['email'] ?? ''); ?>">
                        </div>
                        
                        <div class="form-group">
                            <label for="numero_id">Número de Identificação (3 dígitos) *</label>
                            <input type="number" id="numero_id" name="numero_id" min="100" max="999" required 
                                   value="<?php echo e($usuario_edicao['numero_id'] ?? ''); ?>">
                        </div>
                        
                        <div class="form-group">
                            <label for="senha"><?php echo $acao === 'criar' ? 'Senha *' : 'Senha *'; ?></label>
                            <input type="text" id="senha" name="senha" required
                                   value="<?php echo e($usuario_edicao['senha'] ?? ''); ?>"
                                   <?php echo $acao === 'criar' ? 'minlength="6"' : ''; ?>>
                        </div>
                        
                        <div class="form-group">
                            <label for="turma">turma</label>
                            <input type="text" id="turma" name="turma" 
                                   value="<?php echo e($usuario_edicao['turma'] ?? 'Desconhecido'); ?>">
                        </div>
                        
                        <div class="form-group">
                            <label for="status">Status</label>
                            <select id="status" name="status">
                                <option value="ativo" <?php echo ($usuario_edicao['status'] ?? 'ativo') === 'ativo' ? 'selected' : ''; ?>>Ativo</option>
                                <option value="inativo" <?php echo ($usuario_edicao['status'] ?? '') === 'inativo' ? 'selected' : ''; ?>>Inativo</option>
                            </select>
                        </div>
                        
                        <button type="submit" class="btn btn-primary">Salvar</button>
                        <a href="admin_usuarios.php" class="btn btn-secondary">Cancelar</a>
                    </form>
                </div>
            </div>
        <?php else: ?>
            <div class="card">
                <div class="card-body">
                    <h2>Lista de Usuários</h2>
                    
                    <?php if (empty($usuarios)): ?>
                        <p class="text-muted">Nenhum usuário encontrado.</p>
                    <?php else: ?>
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Nome</th>
                                    <th>E-mail</th>
                                    <th>Senha</th>
                                    <th>Número ID</th>
                                    <th>Turma</th>
                                    <th>Status</th>
                                    <th>Data Cadastro</th>
                                    <th>Ações</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($usuarios as $usuario): ?>
                                    <tr>
                                        <td><?php echo e($usuario['id']); ?></td>
                                        <td><?php echo e($usuario['nome']); ?></td>
                                        <td><?php echo e($usuario['email']); ?></td>
                                        <td><?php echo e($usuario['senha']); ?></td>
                                        <td><strong><?php echo e($usuario['numero_id']); ?></strong></td>
                                        <td><?php echo e($usuario['turma']); ?></td>
                                        <td>
                                            <span class="badge <?php echo $usuario['status'] === 'ativo' ? 'badge-success' : 'badge-secondary'; ?>">
                                                <?php echo ucfirst($usuario['status']); ?>
                                            </span>
                                        </td>
                                        <td><?php echo formatarData($usuario['data_cadastro']); ?></td>
                                        <td>
                                            <a href="?acao=editar&id=<?php echo $usuario['id']; ?>" 
                                               class="btn btn-sm btn-primary">Editar</a>
                                            <?php if ($usuario['id'] != $_SESSION['usuario_id']): ?>
                                                <a href="?acao=deletar&id=<?php echo $usuario['id']; ?>" 
                                                   class="btn btn-sm btn-danger"
                                                   onclick="return confirm('Tem certeza que deseja deletar este usuário?');">
                                                    Deletar
                                                </a>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php endif; ?>
                </div>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>

