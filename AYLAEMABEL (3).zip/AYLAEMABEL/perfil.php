<?php
require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/functions.php';

$conn = getDB();
$usuario = getUserInfo($conn, $_SESSION['usuario_id']);

$mensagem = '';
$tipo_mensagem = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = trim($_POST['nome'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $turma = trim($_POST['turma'] ?? '');
    $senha_atual = $_POST['senha_atual'] ?? '';
    $nova_senha = $_POST['nova_senha'] ?? '';
    $confirmar_senha = $_POST['confirmar_senha'] ?? '';
    
    if (empty($nome) || empty($email)) {
        $mensagem = 'Nome e email são obrigatórios.';
        $tipo_mensagem = 'error';
    } else {
        $stmt = $conn->prepare("SELECT id FROM usuarios WHERE email = ? AND id != ?");
        $stmt->execute([$email, $_SESSION['usuario_id']]);
        
        if ($stmt->rowCount() > 0) {
            $mensagem = 'Este email já está sendo usado por outro usuário.';
            $tipo_mensagem = 'error';
        } else {
            $stmt = $conn->prepare("
                UPDATE usuarios 
                SET nome = ?, email = ?, turma = ? 
                WHERE id = ?
            ");
            $stmt->execute([$nome, $email, $turma, $_SESSION['usuario_id']]);
            
            if (!empty($senha_atual) && !empty($nova_senha)) {
                if ($usuario['senha'] === $senha_atual) {
                    if ($nova_senha === $confirmar_senha) {
                        if (strlen($nova_senha) >= 6) {
                            $stmt = $conn->prepare("UPDATE usuarios SET senha = ? WHERE id = ?");
                            $stmt->execute([$nova_senha, $_SESSION['usuario_id']]);
                            $mensagem = 'Perfil e senha atualizados com sucesso!';
                            $tipo_mensagem = 'success';
                        } else {
                            $mensagem = 'A nova senha deve ter no mínimo 6 caracteres.';
                            $tipo_mensagem = 'error';
                        }
                    } else {
                        $mensagem = 'As senhas não coincidem.';
                        $tipo_mensagem = 'error';
                    }
                } else {
                    $mensagem = 'Senha atual incorreta.';
                    $tipo_mensagem = 'error';
                }
            } else {
                $mensagem = 'Perfil atualizado com sucesso!';
                $tipo_mensagem = 'success';
            }
            
            $_SESSION['usuario_nome'] = $nome;
            $_SESSION['usuario_email'] = $email;
            $usuario = getUserInfo($conn, $_SESSION['usuario_id']);
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Meu Perfil - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <?php include __DIR__ . '/includes/navbar.php'; ?>
    
    <div class="container">
        <h1>Meu Perfil</h1>
        
        <?php if ($mensagem): ?>
            <div class="alert alert-<?php echo $tipo_mensagem; ?>">
                <?php echo e($mensagem); ?>
            </div>
        <?php endif; ?>
        
        <div class="card">
            <div class="card-body">
                <h2>Editar Informações</h2>
                <form method="POST" action="">
                    <div class="form-group">
                        <label for="nome">Nome Completo</label>
                        <input type="text" id="nome" name="nome" required 
                               value="<?php echo e($usuario['nome']); ?>">
                    </div>
                    
                    <div class="form-group">
                        <label for="email">E-mail</label>
                        <input type="email" id="email" name="email" required 
                               value="<?php echo e($usuario['email']); ?>">
                    </div>
                    
                    <div class="form-group">
                        <label for="turma">Turma</label>
                        <input type="text" id="turma" name="turma" 
                               value="<?php echo e($usuario['turma']); ?>">
                    </div>
                    
                    <div class="form-group">
                        <label>Número de Identificação</label>
                        <input type="text" value="<?php echo e($usuario['numero_id']); ?>" 
                               disabled class="disabled-input">
                        <small class="form-text">O número de identificação não pode ser alterado.</small>
                    </div>
                    
                    <hr>
                    
                    <h3>Alterar Senha (opcional)</h3>
                    <div class="form-group">
                        <label for="senha_atual">Senha Atual</label>
                        <input type="password" id="senha_atual" name="senha_atual">
                    </div>
                    
                    <div class="form-group">
                        <label for="nova_senha">Nova Senha</label>
                        <input type="password" id="nova_senha" name="nova_senha" minlength="6">
                    </div>
                    
                    <div class="form-group">
                        <label for="confirmar_senha">Confirmar Nova Senha</label>
                        <input type="password" id="confirmar_senha" name="confirmar_senha" minlength="6">
                    </div>
                    
                    <button type="submit" class="btn btn-primary">Salvar Alterações</button>
                </form>
            </div>
        </div>
    </div>
</body>
</html>

