<?php
define('DB_HOST', 'localhost');
define('DB_NAME', 'sistema_presenca');
define('DB_USER', 'root');
define('DB_PASS', '');
define('SITE_URL', 'http://localhost/AYLAEMABEL/');
define('SITE_NAME', 'Sistema de Controle de Presença');

ini_set('session.cookie_httponly', 1);
ini_set('session.use_only_cookies', 1);
ini_set('session.cookie_secure', 0); 

date_default_timezone_set('America/Sao_Paulo');

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>

