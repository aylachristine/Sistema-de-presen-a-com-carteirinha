<?php
require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/functions.php';

$conn = getDB();
$usuario = getUserInfo($conn, $_SESSION['usuario_id']);


$mes_atual = $_GET['mes'] ?? date('m');
$ano_atual = $_GET['ano'] ?? date('Y');


$registros = getRegistrosPonto($conn, $_SESSION['usuario_id'], 10);


$presencas = getPresencasPorMes($conn, $_SESSION['usuario_id'], $mes_atual, $ano_atual);


$diasDoMes = getDiasDoMes($mes_atual, $ano_atual);


$totalPresencas = count($presencas);
$diasNoMes = count($diasDoMes);
$totalFaltas = $diasNoMes - $totalPresencas; 
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <?php include __DIR__ . '/includes/navbar.php'; ?>
    
    <div class="container">
        <h1>Dashboard - <?php echo e($usuario['nome']); ?></h1>
        

        <div class="card mb-3">
            <div class="card-body">
                <h2>Informações Pessoais</h2>
                <div class="info-grid">
                    <div><strong>Nome:</strong> <?php echo e($usuario['nome']); ?></div>
                    <div><strong>E-mail:</strong> <?php echo e($usuario['email']); ?></div>
                    <div><strong>Número de ID:</strong> <?php echo e($usuario['numero_id']); ?></div>
                    <div><strong>Turma:</strong> <?php echo e($usuario['turma']); ?></div>
                </div>
            </div>
        </div>
        

        <div class="stats-grid">
            <div class="stat-card">
                <h3>Presenças no Mês</h3>
                <div class="stat-value"><?php echo $totalPresencas; ?></div>
            </div>
            <div class="stat-card stat-card-faltas">
                <h3>Faltas no Mês</h3>
                <div class="stat-value"><?php echo $totalFaltas; ?></div>
            </div>
            <div class="stat-card">
                <h3>Total de Registros</h3>
                <div class="stat-value"><?php echo count($registros); ?></div>
            </div>
        </div>
        

        <div class="card mb-3">
            <div class="card-body">
                <h2>Calendário de Presenças - <?php echo date('m/Y', strtotime("$ano_atual-$mes_atual-01")); ?></h2>
                
                <div class="calendario-container">
                    <?php foreach ($diasDoMes as $dia): 
                        $diaSemana = ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'];
                        $temPresenca = isset($presencas[$dia['data']]);
                        $hoje = date('Y-m-d') === $dia['data'];
                    ?>
                        <div class="dia-calendario <?php echo $temPresenca ? 'presente' : ($hoje ? 'hoje' : 'faltou'); ?>">
                            <div class="dia-numero"><?php echo $dia['dia']; ?></div>
                            <div class="dia-label"><?php echo $diaSemana[$dia['diaSemana']]; ?></div>
                            <?php if ($temPresenca): ?>
                                <div class="dia-status">✓</div>
                            <?php elseif ($hoje): ?>
                                <div class="dia-status">Hoje</div>
                            <?php else: ?>
                                <div class="dia-status">✗</div>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                </div>
                
                <div class="legenda-calendario">
                    <span class="legenda-item"><span class="legenda-cor presente"></span> Presente</span>
                    <span class="legenda-item"><span class="legenda-cor faltou"></span> Faltou</span>
                    <span class="legenda-item"><span class="legenda-cor hoje"></span> Hoje</span>
                </div>
            </div>
        </div>
        

        <div class="card">
            <div class="card-body">
                <h2>Últimos Registros de Presença</h2>
                
                <?php if (empty($registros)): ?>
                    <p class="text-muted">Nenhum registro encontrado.</p>
                <?php else: ?>
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Número de ID</th>
                                <th>Data/Hora</th>
                                <th>Tipo</th>
                                <th>Observação</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($registros as $registro): ?>
                                <tr>
                                    <td><strong><?php echo e($registro['numero_id'] ?? ($usuario['numero_id'] ?? '-')); ?></strong></td>
                                    <td><?php echo formatarDataHora($registro['data_hora']); ?></td>
                                    <td>
                                        <span class="badge badge-success">
                                            <?php echo ucfirst($registro['tipo']); ?>
                                        </span>
                                    </td>
                                    <td><?php echo e($registro['observacao'] ?? '-'); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>
    </div>
</body>
</html>

