<?php
require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/functions.php';

$erro = '';
$sucesso = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = trim($_POST['nome'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $senha = $_POST['senha'] ?? '';
    $confirmar_senha = $_POST['confirmar_senha'] ?? '';
    
    if (empty($nome) || empty($email) || empty($senha)) {
        $erro = 'Por favor, preencha todos os campos.';
    } elseif ($senha !== $confirmar_senha) {
        $erro = 'As senhas não coincidem.';
    } elseif (strlen($senha) < 6) {
        $erro = 'A senha deve ter no mínimo 6 caracteres.';
    } else {
        $conn = getDB();
        
        $stmt = $conn->prepare("SELECT id FROM usuarios WHERE email = ?");
        $stmt->execute([$email]);
        
        if ($stmt->rowCount() > 0) {
            $erro = 'Este email já está cadastrado.';
        } else {
            $numero_id = gerarNumeroID($conn);
            
            $stmt = $conn->prepare("
                INSERT INTO usuarios (nome, email, senha, numero_id) 
                VALUES (?, ?, ?, ?)
            ");
            
            if ($stmt->execute([$nome, $email, $senha, $numero_id])) {
                $sucesso = "Registro realizado com sucesso! Seu número de identificação é: <strong>{$numero_id}</strong>. Guarde este número!";
            } else {
                $erro = 'Erro ao realizar registro. Tente novamente.';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <div class="container">
        <div class="auth-box">
            <h1>Cadastro de Usuário</h1>
            
            <?php if ($erro): ?>
                <div class="alert alert-error"><?php echo e($erro); ?></div>
            <?php endif; ?>
            
            <?php if ($sucesso): ?>
                <div class="alert alert-success"><?php echo $sucesso; ?></div>
                <a href="login.php" class="btn btn-primary">Ir para Login</a>
            <?php else: ?>
                <form method="POST" action="">
                    <div class="form-group">
                        <label for="nome">Nome Completo</label>
                        <input type="text" id="nome" name="nome" required 
                               value="<?php echo e($_POST['nome'] ?? ''); ?>">
                    </div>
                    
                    <div class="form-group">
                        <label for="email">E-mail</label>
                        <input type="email" id="email" name="email" required 
                               value="<?php echo e($_POST['email'] ?? ''); ?>">
                    </div>
                    
                    <div class="form-group">
                        <label for="senha">Senha</label>
                        <input type="password" id="senha" name="senha" required 
                               minlength="6">
                    </div>
                    
                    <div class="form-group">
                        <label for="confirmar_senha">Confirmar Senha</label>
                        <input type="password" id="confirmar_senha" name="confirmar_senha" required>
                    </div>
                    
                    <button type="submit" class="btn btn-primary btn-block">Registrar</button>
                </form>
                
                <div class="auth-links">
                    <p>Já tem uma conta? <a href="login.php">Faça login</a></p>
                    <p><a href="index.php">Voltar para página inicial</a></p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>

