<?php
require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/functions.php';

requireAdmin();

$conn = getDB();
$mensagem = '';
$tipo_mensagem = '';
$acao = $_GET['acao'] ?? 'listar';
$id = $_GET['id'] ?? null;


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $chave = trim($_POST['chave'] ?? '');
    $valor = trim($_POST['valor'] ?? '');
    $descricao = trim($_POST['descricao'] ?? '');
    
    if ($acao === 'criar') {
        if (empty($chave)) {
            $mensagem = 'A chave é obrigatória.';
            $tipo_mensagem = 'error';
        } else {
            $stmt = $conn->prepare("SELECT id FROM configuracoes WHERE chave = ?");
            $stmt->execute([$chave]);
            if ($stmt->rowCount() > 0) {
                $mensagem = 'Esta chave já existe.';
                $tipo_mensagem = 'error';
            } else {
                $stmt = $conn->prepare("
                    INSERT INTO configuracoes (chave, valor, descricao) 
                    VALUES (?, ?, ?)
                ");
                if ($stmt->execute([$chave, $valor, $descricao])) {
                    $mensagem = 'Configuração criada com sucesso!';
                    $tipo_mensagem = 'success';
                    $acao = 'listar';
                } else {
                    $mensagem = 'Erro ao criar configuração.';
                    $tipo_mensagem = 'error';
                }
            }
        }
    } elseif ($acao === 'editar' && $id) {
        if (empty($chave)) {
            $mensagem = 'A chave é obrigatória.';
            $tipo_mensagem = 'error';
        } else {
            $stmt = $conn->prepare("SELECT id FROM configuracoes WHERE chave = ? AND id != ?");
            $stmt->execute([$chave, $id]);
            if ($stmt->rowCount() > 0) {
                $mensagem = 'Esta chave já existe em outra configuração.';
                $tipo_mensagem = 'error';
            } else {
                $stmt = $conn->prepare("
                    UPDATE configuracoes 
                    SET chave = ?, valor = ?, descricao = ? 
                    WHERE id = ?
                ");
                if ($stmt->execute([$chave, $valor, $descricao, $id])) {
                    $mensagem = 'Configuração atualizada com sucesso!';
                    $tipo_mensagem = 'success';
                    $acao = 'listar';
                } else {
                    $mensagem = 'Erro ao atualizar configuração.';
                    $tipo_mensagem = 'error';
                }
            }
        }
    }
}

if ($acao === 'deletar' && $id) {
    $stmt = $conn->prepare("DELETE FROM configuracoes WHERE id = ?");
    if ($stmt->execute([$id])) {
        $mensagem = 'Configuração deletada com sucesso!';
        $tipo_mensagem = 'success';
    } else {
        $mensagem = 'Erro ao deletar configuração.';
        $tipo_mensagem = 'error';
    }
    $acao = 'listar';
}

$configuracoes = [];
if ($acao === 'listar') {
    $stmt = $conn->query("SELECT * FROM configuracoes ORDER BY chave ASC");
    $configuracoes = $stmt->fetchAll();
}


$config_edicao = null;
if ($acao === 'editar' && $id) {
    $stmt = $conn->prepare("SELECT * FROM configuracoes WHERE id = ?");
    $stmt->execute([$id]);
    $config_edicao = $stmt->fetch();
    if (!$config_edicao) {
        $mensagem = 'Configuração não encontrada.';
        $tipo_mensagem = 'error';
        $acao = 'listar';
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gerenciar Configurações - Admin</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <?php include __DIR__ . '/includes/navbar.php'; ?>
    
    <div class="container">
        <h1>Gerenciar Configurações</h1>
        
        <div style="margin-bottom: 20px;">
            <a href="admin.php" class="btn btn-secondary">← Voltar para Admin</a>
            <a href="?acao=criar" class="btn btn-primary">+ Nova Configuração</a>
        </div>
        
        <?php if ($mensagem): ?>
            <div class="alert alert-<?php echo $tipo_mensagem; ?>">
                <?php echo e($mensagem); ?>
            </div>
        <?php endif; ?>
        
        <?php if ($acao === 'criar' || ($acao === 'editar' && $config_edicao)): ?>
            <div class="card">
                <div class="card-body">
                    <h2><?php echo $acao === 'criar' ? 'Criar Nova Configuração' : 'Editar Configuração'; ?></h2>
                    <form method="POST" action="?acao=<?php echo $acao; ?><?php echo $id ? '&id=' . $id : ''; ?>">
                        <div class="form-group">
                            <label for="chave">Chave *</label>
                            <input type="text" id="chave" name="chave" required 
                                   value="<?php echo e($config_edicao['chave'] ?? ''); ?>"
                                   placeholder="ex: nome_empresa, horario_trabalho">
                            <small class="form-text">Identificador único da configuração (sem espaços)</small>
                        </div>
                        
                        <div class="form-group">
                            <label for="valor">Valor</label>
                            <textarea id="valor" name="valor" rows="3"><?php echo e($config_edicao['valor'] ?? ''); ?></textarea>
                            <small class="form-text">Valor da configuração (pode ser texto, número, JSON, etc)</small>
                        </div>
                        
                        <div class="form-group">
                            <label for="descricao">Descrição</label>
                            <input type="text" id="descricao" name="descricao" 
                                   value="<?php echo e($config_edicao['descricao'] ?? ''); ?>"
                                   placeholder="Breve descrição do que esta configuração faz">
                        </div>
                        
                        <button type="submit" class="btn btn-primary">Salvar</button>
                        <a href="admin_configuracoes.php" class="btn btn-secondary">Cancelar</a>
                    </form>
                </div>
            </div>
        <?php else: ?>
            <div class="card">
                <div class="card-body">
                    <h2>Lista de Configurações</h2>
                    
                    <?php if (empty($configuracoes)): ?>
                        <p class="text-muted">Nenhuma configuração encontrada.</p>
                    <?php else: ?>
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Chave</th>
                                    <th>Valor</th>
                                    <th>Descrição</th>
                                    <th>Ações</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($configuracoes as $config): ?>
                                    <tr>
                                        <td><?php echo e($config['id']); ?></td>
                                        <td><strong><?php echo e($config['chave']); ?></strong></td>
                                        <td><?php echo e($config['valor'] ?? '-'); ?></td>
                                        <td><?php echo e($config['descricao'] ?? '-'); ?></td>
                                        <td>
                                            <a href="?acao=editar&id=<?php echo $config['id']; ?>" 
                                               class="btn btn-sm btn-primary">Editar</a>
                                            <a href="?acao=deletar&id=<?php echo $config['id']; ?>" 
                                               class="btn btn-sm btn-danger"
                                               onclick="return confirm('Tem certeza que deseja deletar esta configuração?');">
                                                Deletar
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php endif; ?>
                </div>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>

