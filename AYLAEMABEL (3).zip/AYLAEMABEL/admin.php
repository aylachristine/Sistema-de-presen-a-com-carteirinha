<?php
require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/functions.php';

requireAdmin(); 

$conn = getDB();


$stats = [];

$stmt = $conn->query("SELECT COUNT(*) as total FROM usuarios");
$stats['usuarios'] = $stmt->fetch()['total'];

$stmt = $conn->query("SELECT COUNT(*) as total FROM registros_ponto");
$stats['registros'] = $stmt->fetch()['total'];

$stmt = $conn->query("SELECT COUNT(*) as total FROM configuracoes");
$stats['configuracoes'] = $stmt->fetch()['total'];

$hoje = date('Y-m-d');
$stmt = $conn->prepare("SELECT COUNT(*) as total FROM registros_ponto WHERE DATE(data_hora) = ?");
$stmt->execute([$hoje]);
$stats['registros_hoje'] = $stmt->fetch()['total'];
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Painel Administrativo - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <?php include __DIR__ . '/includes/navbar.php'; ?>
    
    <div class="container">
        <h1>Painel Administrativo</h1>
        
        <div class="stats-grid">
            <div class="stat-card">
                <h3>Total de Usuários</h3>
                <div class="stat-value"><?php echo $stats['usuarios']; ?></div>
            </div>
            <div class="stat-card">
                <h3>Total de Registros</h3>
                <div class="stat-value"><?php echo $stats['registros']; ?></div>
            </div>
            <div class="stat-card">
                <h3>Registros Hoje</h3>
                <div class="stat-value"><?php echo $stats['registros_hoje']; ?></div>
            </div>
            <div class="stat-card">
                <h3>Configurações</h3>
                <div class="stat-value"><?php echo $stats['configuracoes']; ?></div>
            </div>
        </div>
        
        <div class="features-grid" style="margin-top: 30px;">
            <div class="feature-card" style="cursor: pointer;" onclick="window.location='admin_usuarios.php'">
                <h3>👥 Gerenciar Usuários</h3>
                <p>Cadastrar, editar e excluir usuários do sistema</p>
                <p><strong>Total: <?php echo $stats['usuarios']; ?> usuários</strong></p>
            </div>
            
            <div class="feature-card" style="cursor: pointer;" onclick="window.location='admin_registros.php'">
                <h3>📋 Gerenciar Registros de Ponto</h3>
                <p>Visualizar, editar e gerenciar todos os registros de ponto</p>
                <p><strong>Total: <?php echo $stats['registros']; ?> registros</strong></p>
            </div>
            
            <div class="feature-card" style="cursor: pointer;" onclick="window.location='admin_configuracoes.php'">
                <h3>⚙️ Gerenciar Configurações</h3>
                <p>Configurar parâmetros do sistema</p>
                <p><strong>Total: <?php echo $stats['configuracoes']; ?> configurações</strong></p>
            </div>
        </div>
    </div>
</body>
</html>

