<?php

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/functions.php';


$public_pages = ['index.php', 'login.php', 'registro.php'];

$current_page = basename($_SERVER['PHP_SELF']);

if (!in_array($current_page, $public_pages) && !isLoggedIn()) {
    redirect('login.php');
}

if (in_array($current_page, ['login.php', 'registro.php']) && isLoggedIn()) {
  
    if (isAdmin()) {
        redirect('admin.php');
    } else {
        redirect('dashboard.php');
    }
}
?>

