<?php
if (!isset($_SESSION)) {
    session_start();
}
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/functions.php';
?>
<nav class="navbar">
    <div class="navbar-container">
        <div class="navbar-brand">
            <a href="index.php"><?php echo SITE_NAME; ?></a>
        </div>
        <ul class="navbar-menu">
            <?php if (isLoggedIn()): ?>
                <?php if (isAdmin()): ?>
                    <li><a href="admin.php">Admin</a></li>
                <?php endif; ?>
                <li><a href="dashboard.php">Dashboard</a></li>
                <li><a href="bater_ponto.php">Marcar Presença</a></li>
                <li><a href="perfil.php">Meu Perfil</a></li>
                <li><a href="logout.php" class="logout-link">Sair</a></li>
            <?php else: ?>
                <li><a href="login.php">Login</a></li>
                <li><a href="registro.php">Registro</a></li>
            <?php endif; ?>
        </ul>
    </div>
</nav>

