<?php
function isLoggedIn() {
    return isset($_SESSION['usuario_id']);
}

function isAdmin() {
    return isset($_SESSION['is_admin']) && $_SESSION['is_admin'] === true;
}

function requireAdmin() {
    if (!isAdmin()) {
        redirect('dashboard.php');
    }
}

function redirect($page = 'index.php') {
    header("Location: " . $page);
    exit();
}

function e($string) {
    return htmlspecialchars($string, ENT_QUOTES, 'UTF-8');
}


function gerarNumeroID($conn) {
    do {
        $numero = rand(100, 999);
        $stmt = $conn->prepare("SELECT id FROM usuarios WHERE numero_id = ?");
        $stmt->execute([$numero]);
    } while ($stmt->rowCount() > 0);
    
    return $numero;
}


function formatarDataHora($timestamp) {
    return date('d/m/Y H:i:s', strtotime($timestamp));
}


function formatarData($timestamp) {
    return date('d/m/Y', strtotime($timestamp));
}


function getUserInfo($conn, $user_id) {
    $stmt = $conn->prepare("SELECT * FROM usuarios WHERE id = ?");
    $stmt->execute([$user_id]);
    return $stmt->fetch();
}


function jaBateuPontoHoje($conn, $user_id) {
    $hoje = date('Y-m-d');
    $stmt = $conn->prepare("
        SELECT COUNT(*) as total 
        FROM registros_ponto 
        WHERE usuario_id = ? 
        AND DATE(data_hora) = ?
    ");
    $stmt->execute([$user_id, $hoje]);
    $result = $stmt->fetch();
    return $result['total'] > 0;
}


function getRegistrosPonto($conn, $user_id, $limit = null) {
    $sql = "SELECT * FROM registros_ponto WHERE usuario_id = ? ORDER BY data_hora DESC";
    if ($limit) {
        $sql .= " LIMIT " . intval($limit);
    }
    $stmt = $conn->prepare($sql);
    $stmt->execute([$user_id]);
    return $stmt->fetchAll();
}

function getDiasDoMes($mes = null, $ano = null) {
    $mes = $mes ?: date('m');
    $ano = $ano ?: date('Y');
    $diasNoMes = cal_days_in_month(CAL_GREGORIAN, $mes, $ano);
    $dias = [];
    
    for ($dia = 1; $dia <= $diasNoMes; $dia++) {
        $data = sprintf('%04d-%02d-%02d', $ano, $mes, $dia);
        $dias[] = [
            'dia' => $dia,
            'data' => $data,
            'diaSemana' => date('w', strtotime($data))
        ];
    }
    
    return $dias;
}


function getPresencasPorMes($conn, $user_id, $mes = null, $ano = null) {
    $mes = $mes ?: date('m');
    $ano = $ano ?: date('Y');
    
    $stmt = $conn->prepare("
        SELECT DATE(data_hora) as data, COUNT(*) as total
        FROM registros_ponto
        WHERE usuario_id = ?
        AND MONTH(data_hora) = ?
        AND YEAR(data_hora) = ?
        GROUP BY DATE(data_hora)
    ");
    $stmt->execute([$user_id, $mes, $ano]);
    
    $presencas = [];
    while ($row = $stmt->fetch()) {
        $presencas[$row['data']] = $row['total'];
    }
    
    return $presencas;
}
?>
