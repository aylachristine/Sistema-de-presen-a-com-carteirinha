<?php
require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/functions.php';
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <div class="container">
        <div class="hero-section">
            <h1><?php echo SITE_NAME; ?></h1>
            <p class="subtitle">Sistema de controle de presença e ponto eletrônico</p>
            
            <?php if (isLoggedIn()): ?>
                <div class="hero-actions">
                    <a href="dashboard.php" class="btn btn-primary btn-large">Acessar Dashboard</a>
                    <a href="bater_ponto.php" class="btn btn-secondary btn-large">Bater Ponto</a>
                </div>
            <?php else: ?>
                <div class="hero-actions">
                    <a href="login.php" class="btn btn-primary btn-large">Fazer Login</a>
                    <a href="registro.php" class="btn btn-secondary btn-large">Criar Conta</a>
                </div>
            <?php endif; ?>
        </div>
        
        <div class="features-grid">
            <div class="feature-card">
                <h3>📋 Controle de Presença</h3>
                <p>Registre sua presença de forma simples e rápida usando seu número de identificação.</p>
            </div>
            
            <div class="feature-card">
                <h3>📊 Dashboard Completo</h3>
                <p>Visualize seus registros, presenças e faltas em um calendário interativo.</p>
            </div>
            
            <div class="feature-card">
                <h3>🔒 Seguro e Confiável</h3>
                <p>Sistema seguro com autenticação por senha e identificação única.</p>
            </div>
        </div>
    </div>
</body>
</html>

