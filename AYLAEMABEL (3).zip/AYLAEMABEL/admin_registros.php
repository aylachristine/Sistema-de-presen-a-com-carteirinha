<?php
require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/functions.php';

requireAdmin();

$conn = getDB();
$mensagem = '';
$tipo_mensagem = '';
$acao = $_GET['acao'] ?? 'listar';
$id = $_GET['id'] ?? null;


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $usuario_id = trim($_POST['usuario_id'] ?? '');
    $numero_id = trim($_POST['numero_id'] ?? '');
    $data_hora = $_POST['data_hora'] ?? '';
    $tipo = $_POST['tipo'] ?? 'entrada';
    $observacao = trim($_POST['observacao'] ?? '');
    
    if ($acao === 'criar') {
        if (empty($usuario_id) || empty($numero_id) || empty($data_hora)) {
            $mensagem = 'Por favor, preencha todos os campos obrigatórios.';
            $tipo_mensagem = 'error';
        } else {
            $stmt = $conn->prepare("
                INSERT INTO registros_ponto (usuario_id, numero_id, data_hora, tipo, observacao) 
                VALUES (?, ?, ?, ?, ?)
            ");
            if ($stmt->execute([$usuario_id, $numero_id, $data_hora, $tipo, $observacao])) {
                $mensagem = 'Registro criado com sucesso!';
                $tipo_mensagem = 'success';
                $acao = 'listar';
            } else {
                $mensagem = 'Erro ao criar registro.';
                $tipo_mensagem = 'error';
            }
        }
    } elseif ($acao === 'editar' && $id) {
        if (empty($usuario_id) || empty($numero_id) || empty($data_hora)) {
            $mensagem = 'Por favor, preencha todos os campos obrigatórios.';
            $tipo_mensagem = 'error';
        } else {
            $stmt = $conn->prepare("
                UPDATE registros_ponto 
                SET usuario_id = ?, numero_id = ?, data_hora = ?, tipo = ?, observacao = ? 
                WHERE id = ?
            ");
            if ($stmt->execute([$usuario_id, $numero_id, $data_hora, $tipo, $observacao, $id])) {
                $mensagem = 'Registro atualizado com sucesso!';
                $tipo_mensagem = 'success';
                $acao = 'listar';
            } else {
                $mensagem = 'Erro ao atualizar registro.';
                $tipo_mensagem = 'error';
            }
        }
    }
}

if ($acao === 'deletar' && $id) {
    $stmt = $conn->prepare("DELETE FROM registros_ponto WHERE id = ?");
    if ($stmt->execute([$id])) {
        $mensagem = 'Registro deletado com sucesso!';
        $tipo_mensagem = 'success';
    } else {
        $mensagem = 'Erro ao deletar registro.';
        $tipo_mensagem = 'error';
    }
    $acao = 'listar';
}


$registros = [];
if ($acao === 'listar') {
    $stmt = $conn->query("
        SELECT rp.*, u.nome as usuario_nome, u.email as usuario_email
        FROM registros_ponto rp
        LEFT JOIN usuarios u ON rp.usuario_id = u.id
        ORDER BY rp.data_hora DESC
        LIMIT 100
    ");
    $registros = $stmt->fetchAll();
}


$registro_edicao = null;
if ($acao === 'editar' && $id) {
    $stmt = $conn->prepare("SELECT * FROM registros_ponto WHERE id = ?");
    $stmt->execute([$id]);
    $registro_edicao = $stmt->fetch();
    if (!$registro_edicao) {
        $mensagem = 'Registro não encontrado.';
        $tipo_mensagem = 'error';
        $acao = 'listar';
    }
}


$usuarios = [];
$stmt = $conn->query("SELECT id, nome, numero_id FROM usuarios ORDER BY nome");
$usuarios = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gerenciar Registros - Admin</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <?php include __DIR__ . '/includes/navbar.php'; ?>
    
    <div class="container">
        <h1>Gerenciar Registros de Ponto</h1>
        
        <div style="margin-bottom: 20px;">
            <a href="admin.php" class="btn btn-secondary">← Voltar para Admin</a>
            <a href="?acao=criar" class="btn btn-primary">+ Novo Registro</a>
        </div>
        
        <?php if ($mensagem): ?>
            <div class="alert alert-<?php echo $tipo_mensagem; ?>">
                <?php echo e($mensagem); ?>
            </div>
        <?php endif; ?>
        
        <?php if ($acao === 'criar' || ($acao === 'editar' && $registro_edicao)): ?>
            <div class="card">
                <div class="card-body">
                    <h2><?php echo $acao === 'criar' ? 'Criar Novo Registro' : 'Editar Registro'; ?></h2>
                    <form method="POST" action="?acao=<?php echo $acao; ?><?php echo $id ? '&id=' . $id : ''; ?>">
                        <div class="form-group">
                            <label for="usuario_id">Usuário *</label>
                            <select id="usuario_id" name="usuario_id" required onchange="updateNumeroId(this)">
                                <option value="">Selecione um usuário</option>
                                <?php foreach ($usuarios as $usuario): ?>
                                    <option value="<?php echo $usuario['id']; ?>" 
                                            data-numero-id="<?php echo $usuario['numero_id']; ?>"
                                            <?php echo ($registro_edicao['usuario_id'] ?? '') == $usuario['id'] ? 'selected' : ''; ?>>
                                        <?php echo e($usuario['nome']); ?> (ID: <?php echo e($usuario['numero_id']); ?>)
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label for="numero_id">Número de Identificação *</label>
                            <input type="number" id="numero_id" name="numero_id" min="100" max="999" required 
                                   value="<?php echo e($registro_edicao['numero_id'] ?? ''); ?>">
                        </div>
                        
                        <div class="form-group">
                            <label for="data_hora">Data/Hora *</label>
                            <input type="datetime-local" id="data_hora" name="data_hora" required 
                                   value="<?php echo $registro_edicao ? date('Y-m-d\TH:i', strtotime($registro_edicao['data_hora'])) : date('Y-m-d\TH:i'); ?>">
                        </div>
                        
                        <div class="form-group">
                            <label for="tipo">Tipo *</label>
                            <select id="tipo" name="tipo" required>
                                <option value="entrada" <?php echo ($registro_edicao['tipo'] ?? 'entrada') === 'entrada' ? 'selected' : ''; ?>>Entrada</option>
                                <option value="saida" <?php echo ($registro_edicao['tipo'] ?? '') === 'saida' ? 'selected' : ''; ?>>Saída</option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label for="observacao">Observação</label>
                            <textarea id="observacao" name="observacao" rows="3"><?php echo e($registro_edicao['observacao'] ?? ''); ?></textarea>
                        </div>
                        
                        <button type="submit" class="btn btn-primary">Salvar</button>
                        <a href="admin_registros.php" class="btn btn-secondary">Cancelar</a>
                    </form>
                </div>
            </div>
            
            <script>
                function updateNumeroId(select) {
                    const selectedOption = select.options[select.selectedIndex];
                    const numeroId = selectedOption.getAttribute('data-numero-id');
                    if (numeroId) {
                        document.getElementById('numero_id').value = numeroId;
                    }
                }
            </script>
        <?php else: ?>
            <div class="card">
                <div class="card-body">
                    <h2>Lista de Registros de Ponto</h2>
                    
                    <?php if (empty($registros)): ?>
                        <p class="text-muted">Nenhum registro encontrado.</p>
                    <?php else: ?>
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Usuário</th>
                                    <th>Número ID</th>
                                    <th>Data/Hora</th>
                                    <th>Tipo</th>
                                    <th>Observação</th>
                                    <th>Ações</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($registros as $registro): ?>
                                    <tr>
                                        <td><?php echo e($registro['id']); ?></td>
                                        <td><?php echo e($registro['usuario_nome'] ?? 'N/A'); ?></td>
                                        <td><strong><?php echo e($registro['numero_id']); ?></strong></td>
                                        <td><?php echo formatarDataHora($registro['data_hora']); ?></td>
                                        <td>
                                            <span class="badge badge-success">
                                                <?php echo ucfirst($registro['tipo']); ?>
                                            </span>
                                        </td>
                                        <td><?php echo e($registro['observacao'] ?? '-'); ?></td>
                                        <td>
                                            <a href="?acao=editar&id=<?php echo $registro['id']; ?>" 
                                               class="btn btn-sm btn-primary">Editar</a>
                                            <a href="?acao=deletar&id=<?php echo $registro['id']; ?>" 
                                               class="btn btn-sm btn-danger"
                                               onclick="return confirm('Tem certeza que deseja deletar este registro?');">
                                                Deletar
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php endif; ?>
                </div>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>

