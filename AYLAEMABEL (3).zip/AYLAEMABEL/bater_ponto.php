<?php
require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/functions.php';

$erro = '';
$sucesso = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $numero_id = trim($_POST['numero_id'] ?? '');
    $senha = $_POST['senha'] ?? '';
    
    if (empty($numero_id) || empty($senha)) {
        $erro = 'Por favor, preencha todos os campos.';
    } else {
        $conn = getDB();
        
        $stmt = $conn->prepare("SELECT * FROM usuarios WHERE numero_id = ? AND status = 'ativo'");
        $stmt->execute([$numero_id]);
        $usuario = $stmt->fetch();
        
        if ($usuario && $usuario['senha'] === $senha) {
            $hoje = date('Y-m-d');
            $stmt = $conn->prepare("
                SELECT COUNT(*) as total 
                FROM registros_ponto 
                WHERE usuario_id = ? 
                AND DATE(data_hora) = ?
            ");
            $stmt->execute([$usuario['id'], $hoje]);
            $result = $stmt->fetch();
            
            if ($result['total'] > 0) {
                $erro = 'Você já bateu ponto hoje!';
            } else {
                $stmt = $conn->prepare("
                    INSERT INTO registros_ponto (usuario_id, numero_id, tipo, observacao) 
                    VALUES (?, ?, 'entrada', 'Ponto registrado pelo sistema')
                ");
                
                if ($stmt->execute([$usuario['id'], $usuario['numero_id']])) {
                    $sucesso = "Ponto registrado com sucesso! Data e hora: " . date('d/m/Y H:i:s');
                    $_POST = []; 
                } else {
                    $erro = 'Erro ao registrar ponto. Tente novamente.';
                }
            }
        } else {
            $erro = 'Número de identificação ou senha incorretos.';
        }
    }
}


$conn = getDB();
$ultimoRegistro = null;
if (isLoggedIn()) {
    $stmt = $conn->prepare("
        SELECT * FROM registros_ponto 
        WHERE usuario_id = ? 
        ORDER BY data_hora DESC 
        LIMIT 1
    ");
    $stmt->execute([$_SESSION['usuario_id']]);
    $ultimoRegistro = $stmt->fetch();
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Marcar presença - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <?php include __DIR__ . '/includes/navbar.php'; ?>
    
    <div class="container">
        <h1>Marcar presença</h1>
        
        <?php if ($erro): ?>
            <div class="alert alert-error"><?php echo e($erro); ?></div>
        <?php endif; ?>
        
        <?php if ($sucesso): ?>
            <div class="alert alert-success"><?php echo e($sucesso); ?></div>
        <?php endif; ?>
        
        <div class="card">
            <div class="card-body">
                <p class="info-text">Digite seu número de identificação e senha para registrar sua presença.</p>
                
                <form method="POST" action="" class="ponto-form">
                    <div class="form-group">
                        <label for="numero_id">Número de Identificação</label>
                        <input type="number" id="numero_id" name="numero_id" 
                               min="100" max="999" required 
                               value="<?php echo e($_POST['numero_id'] ?? ''); ?>"
                               placeholder="Seu número de 3 dígitos">
                    </div>
                    
                    <div class="form-group">
                        <label for="senha">Senha</label>
                        <input type="password" id="senha" name="senha" required>
                    </div>
                    
                    <button type="submit" class="btn btn-primary btn-block btn-large">
                        Registrar Presença
                    </button>
                </form>
                
                <?php if ($ultimoRegistro): ?>
                    <div class="ultimo-registro">
                        <h3>Último Registro:</h3>
                        <p><strong>Data/Hora:</strong> <?php echo formatarDataHora($ultimoRegistro['data_hora']); ?></p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</body>
</html>

